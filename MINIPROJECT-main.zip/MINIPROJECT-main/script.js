const API_BASE      = 'http://localhost:5000/api';
const medicalInput  = document.getElementById('medicalInput');
const fileInput     = document.getElementById('fileInput');
const textBtn       = document.getElementById('textSummarizeBtn');
const fileBtn       = document.getElementById('fileSummarizeBtn');
const voiceBtn      = document.getElementById('voiceBtn');
const voiceLabel    = document.getElementById('voiceLabel');
const styleSelect   = document.getElementById('styleSelect');
const translateSelect = document.getElementById('translateSelect');
const resultCard    = document.getElementById('resultCard');
const outputText    = document.getElementById('outputText');
const loading       = document.getElementById('loading');

let recorder, audioChunks = [];

// Helpers
function getStyle()    { return styleSelect.value; }
function getTranslate() { return translateSelect.value; }
function showLoading() { loading.classList.remove('hidden'); }
function hideLoading() { loading.classList.add('hidden'); }
function showResult(txt) { outputText.textContent = txt; resultCard.classList.remove('hidden'); }
function resetInput() {
  medicalInput.value = '';
  fileInput.value = '';
  translateSelect.value = '';
  resultCard.classList.add('hidden');
}

// Common API caller
async function callAPI(path, body, isForm=false) {
  const opts = { method:'POST' };
  if (isForm) {
    opts.body = body;
  } else {
    opts.headers = {'Content-Type':'application/json'};
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(`${API_BASE}/${path}`, opts);
  return res.json();
}

// Text summarization
textBtn.addEventListener('click', async () => {
  const txt = medicalInput.value.trim();
  if (!txt) return alert('Please enter some medical text.');
  showLoading(); resultCard.classList.add('hidden');
  try {
    const data = await callAPI('summarize', {
      medical_case: txt,
      style: getStyle(),
      translate_to: getTranslate()
    });
    showResult(data.summary);
  } catch(e) {
    alert('Error: '+e.message);
  } finally { hideLoading(); }
});

// File OCR & summarize
fileBtn.addEventListener('click', async () => {
  const file = fileInput.files[0];
  if (!file) return alert('Please select a file.');
  showLoading(); resultCard.classList.add('hidden');
  const form = new FormData();
  form.append('file', file);
  form.append('style', getStyle());
  form.append('translate_to', getTranslate());
  try {
    const data = await callAPI('upload', form, true);
    if (data.error) throw new Error(data.error);
    showResult(data.summary);
  } catch(e) {
    alert('Error: '+e.message);
  } finally { hideLoading(); }
});

// Voice recording & server STT
navigator.mediaDevices.getUserMedia({ audio:true })
  .then(stream => {
    recorder = new MediaRecorder(stream);
    recorder.ondataavailable = e => audioChunks.push(e.data);
    recorder.onstop = sendAudio;
  })
  .catch(() => {
    voiceBtn.disabled = true;
    voiceLabel.textContent = 'Mic Unavailable';
  });

voiceBtn.addEventListener('click', () => {
  if (!recorder) return;
  if (recorder.state==='recording') {
    recorder.stop();
    voiceLabel.textContent = 'Start Recording';
    voiceBtn.classList.remove('recording');
  } else {
    audioChunks = [];
    recorder.start();
    voiceLabel.textContent = 'Stop Recording';
    voiceBtn.classList.add('recording');
    resetInput();
  }
});

async function sendAudio() {
  showLoading(); resultCard.classList.add('hidden');
  const blob = new Blob(audioChunks, { type:'audio/webm' });
  const form = new FormData();
  form.append('audio', blob, 'rec.webm');
  form.append('style', getStyle());
  form.append('translate_to', getTranslate());
  try {
    const data = await callAPI('voice', form, true);
    if (data.error) throw new Error(data.error);
    medicalInput.value = data.transcript;
    showResult(data.summary);
  } catch(e) {
    alert('Error: '+e.message);
  } finally { hideLoading(); }
}
