from flask import Flask, request, jsonify
from flask_cors import CORS
import os, tempfile
from werkzeug.utils import secure_filename

import google.generativeai as genai
import easyocr
import speech_recognition as sr
from pydub import AudioSegment

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Configure Gemini API key
os.environ["GOOGLE_API_KEY"] = "AIzaSyD2tqiRH-J6kOfZTbG9h-EKJdI7nxHoxMc"
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
model = genai.GenerativeModel("gemini-2.0-flash")

# OCR reader
ocr_reader = easyocr.Reader(["en"], gpu=False)

def get_medical_summary(text: str, style: str) -> str:
    prompt = f"""**Medical Case Analysis Request**
    
**Formatting Rules:**
1. Use plain text only (no markdown)
2. Separate sections with blank lines
3. Maintain table-like structure without actual table formatting
4. Use pipes (|) only in medication details
5. Avoid special characters (*, -, >)
6. Keep bullet points aligned with spaces
7. Include dosage ranges where appropriate
8. Use standardized drug names (no brand names)
    
{text}

**Summary Style:** {style}

**Required Output Format:**
"""
    if style == "SOAP":
        prompt += "Use SOAP format (Subjective, Objective, Assessment, Plan)\n\n"
    elif style == "Bullet":
        prompt += "Use bullet points for each section\n\n"
    else:
        prompt += "Write in narrative paragraph form\n\n"

    prompt += "CLINICAL SUMMARY :: [Your summary here]\n"
    response = model.generate_content(prompt)
    return response.text.strip()

def translate_text(text: str, target_lang: str) -> str:
    prompt = f"Translate the following clinical summary into {target_lang} without changing its format:\n\n{text}\n"
    response = model.generate_content(prompt)
    return response.text.strip()

@app.route("/api/summarize", methods=["POST"])
def summarize():
    data = request.get_json() or {}
    case = data.get("medical_case", "").strip()
    style = data.get("style", "Narrative")
    translate_to = data.get("translate_to", "")
    if not case:
        return jsonify({"error": "Missing medical_case"}), 400

    summary = get_medical_summary(case, style)
    if translate_to:
        summary = translate_text(summary, translate_to)
    return jsonify({"summary": summary})

@app.route("/api/upload", methods=["POST"])
def upload_and_summarize():
    file = request.files.get('file')
    style = request.form.get('style', 'Narrative')
    translate_to = request.form.get('translate_to', '')
    if not file or file.filename == '':
        return jsonify({"error": "No file uploaded"}), 400

    tmp_dir = tempfile.gettempdir()
    path = os.path.join(tmp_dir, secure_filename(file.filename))
    file.save(path)
    try:
        texts = ocr_reader.readtext(path, detail=0)
        content = "\n".join(texts)
        summary = get_medical_summary(content, style)
        if translate_to:
            summary = translate_text(summary, translate_to)
        return jsonify({"summary": summary})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        try: os.remove(path)
        except: pass

@app.route("/api/voice", methods=["POST"])
def voice():
    audio = request.files.get('audio')
    style = request.form.get('style', 'Narrative')
    translate_to = request.form.get('translate_to', '')
    if not audio or audio.filename == '':
        return jsonify({"error": "No audio uploaded"}), 400

    tmp_dir = tempfile.gettempdir()
    webm_path = os.path.join(tmp_dir, secure_filename(audio.filename))
    wav_path = webm_path.rsplit('.', 1)[0] + '.wav'
    audio.save(webm_path)
    try:
        AudioSegment.from_file(webm_path).export(wav_path, format='wav')
        recognizer = sr.Recognizer()
        with sr.AudioFile(wav_path) as src:
            audio_data = recognizer.record(src)
            transcript = recognizer.recognize_google(audio_data)
        summary = get_medical_summary(transcript, style)
        if translate_to:
            summary = translate_text(summary, translate_to)
        return jsonify({"transcript": transcript, "summary": summary})
    except sr.UnknownValueError:
        return jsonify({"error": "Could not understand audio"}), 422
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        for p in (webm_path, wav_path):
            try: os.remove(p)
            except: pass

if __name__ == "__main__":
    app.run(debug=True)
