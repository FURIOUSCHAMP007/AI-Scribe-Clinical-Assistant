# Required Libraries
import os
import google.generativeai as genai
import pandas as pd
import speech_recognition as sr

# Configure API Key
os.environ["GOOGLE_API_KEY"] = "AIzaSyD2tqiRH-J6kOfZTbG9h-EKJdI7nxHoxMc"
genai.configure(api_key=os.environ["GOOGLE_API_KEY"])
#model = genai.models.get_model("gemini-2.0-flash")

# Function: Get Summary and Treatment Plan
def get_medical_summary_and_treatment(medical_case):
    prompt = (
        "You're a clinical assistant. Given the medical story below, generate:\n"
        "1. A concise clinical summary using medical jargon.\n"
        "2. A recommended treatment plan (lifestyle, pharmacological, surgical if needed).\n"
        "3. Suggested medications (name, class, dose if applicable).\n\n"
        f"Medical Case:\n{medical_case}"
    )
    try:
        response = genai.generate_text(prompt=prompt)
        return response.result.strip()
    except Exception as e:
        return f"[Error] {str(e)}"

# Function: Display Result Table
def display_results_table(original, ai_response):
    rows = [{
        "User Medical Case": original,
        "AI Clinical Summary + Treatment": ai_response
    }]
    df = pd.DataFrame(rows)
    print("\n📋 Summary & Treatment Plan:\n")
    print(df.to_markdown(index=False, tablefmt="grid"))
    return df

# Function: Save to CSV
def save_to_csv(df):
    df.to_csv("user_medical_case_summaries.csv", mode='a', header=not os.path.exists("user_medical_case_summaries.csv"), index=False)
    print("✅ Summary saved to 'user_medical_case_summaries.csv'")

# Function: Use Speech-to-Text
def recognize_speech():
    recognizer = sr.Recognizer()
    mic = sr.Microphone()

    print("\n🎙️ Listening... Please speak your medical case.")
    with mic as source:
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    try:
        print("📝 Transcribing...")
        text = recognizer.recognize_google(audio)
        print(f"✅ You said: {text}")
        return text
    except sr.UnknownValueError:
        print("❌ Could not understand audio.")
    except sr.RequestError as e:
        print(f"⚠️ STT Request error: {e}")
    return ""

# Main Loop
def summarize_medical_cases():
    print("🔁 Gemini Medical Summarizer (Type 'exit' to quit)\n")
    while True:
        choice = input("📝 Choose input method - [T]ext or [V]oice: ").strip().lower()

        if choice == "exit":
            print("👋 Exiting summarizer.")
            break
        elif choice == 'v':
            user_case = recognize_speech()
        else:
            user_case = input("🩺 Enter a medical story/condition: ").strip()

        if user_case.lower() == "exit":
            print("👋 Exiting summarizer.")
            break

        if not user_case:
            print("⚠️ No input provided.")
            continue

        ai_response = get_medical_summary_and_treatment(user_case)
        df = display_results_table(user_case, ai_response)

        save = input("\n💾 Save this summary? (y/n): ").strip().lower()
        if save == 'y':
            save_to_csv(df)
        print("\n" + "-" * 60 + "\n")

# Run
if __name__ == "__main__":
    summarize_medical_cases()