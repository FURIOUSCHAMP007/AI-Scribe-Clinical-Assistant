import pandas as pd
import numpy as np
from scipy.spatial.distance import cosine
import google.generativeai as genai
os.environ["GOOGLE_API_KEY"] = "AIzaSyD2tqiRH-J6kOfZTbG9h-EKJdI7nxHoxMc"

API_KEY     = "AIzaSyD2tqiRH-J6kOfZTbG9h-EKJdI7nxHoxMc"
EMBED_MODEL = "gemini-embedding-exp-03-07"
CHAT_MODEL  = "models/gemini-2.0-flash"


genai.configure(api_key=API_KEY)


df = pd.read_csv("train.csv")
df = df.dropna(subset=["Conversation"]).reset_index(drop=True)
df = df.head(50)


conversations = df["Conversation"].tolist()


batch_size = 50  
embeddings = []

resp = genai.embed_content(
    model=EMBED_MODEL,
    content=conversations
)
embeddings = np.array([p["embeddings"]["values"] for p in resp["predictions"]])


def retrieve_top_k(query, k=3):
   
    q_emb = genai.embed_content(model=EMBED_MODEL, content=[query])["predictions"][0]["embeddings"]["values"]
   
    dists = [cosine(q_emb, row) for row in embeddings]
    idxs  = np.argsort(dists)[:k]
    return idxs, [conversations[i] for i in idxs]

def ask_gemini(context, question):
    prompt = (
        "Here are some patient–AI conversations:\n\n"
        + "\n\n---\n\n".join(context)
        + f"\n\nBased on these, answer: {question}"
    )
    model = genai.GenerativeModel(CHAT_MODEL)
    resp  = model.generate_text(prompt=prompt)
    return resp.result


